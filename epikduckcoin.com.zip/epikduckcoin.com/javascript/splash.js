var splashScreen = document.querySelector(".splash");
var submarinuLink = document.querySelector(".splashbtnone");
submarinuLink.addEventListener("click", () => {
  splashScreen.style.opacity = 0;
  setTimeout(() => {
    splashScreen.classList.add("hidden");
  }, 610);
});

var splashScreen = document.querySelector(".splash");
var submarinuLink = document.querySelector(".splashbtntwo");
submarinuLink.addEventListener("click", () => {
  splashScreen.style.opacity = 0;
  setTimeout(() => {
    splashScreen.classList.add("hidden");
  }, 610);
});

var splashScreen = document.querySelector(".splash");
var submarinuLink = document.querySelector(".splashbtnexit");
submarinuLink.addEventListener("click", () => {
  splashScreen.style.opacity = 0;
  setTimeout(() => {
    splashScreen.classList.add("hidden");
  }, 610);
});
