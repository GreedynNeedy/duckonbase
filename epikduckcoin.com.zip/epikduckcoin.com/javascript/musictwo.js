function playYes() {
  var audio = new Audio("ohmygod.mp3");
  var music = new Audio("duckmusic.mp3");
  audio.play();
  music.play();
}

function playNo() {
  var audio = new Audio("bruh.mp3");
  var music = new Audio("duckmusic.mp3");
  audio.play();
  music.play();
}

function playExit() {
  var audio = new Audio("quack.mp3");
  audio.play();
}
